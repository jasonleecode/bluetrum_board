cp ../riscv32-elf-xmaker.exe .
cp ../header.bin .
cp ../rtthread.xm .
cp ../download.xm .
