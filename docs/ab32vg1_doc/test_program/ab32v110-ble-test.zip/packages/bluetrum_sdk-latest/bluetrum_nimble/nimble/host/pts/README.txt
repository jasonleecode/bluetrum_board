This folder contains qualification tests results against BT SIG Profile Test
Suite.

pts-FOO.txt files contain result for specific profiles or protocols. This
includes PTS version, test date, enabled tests, results etc.

In addition to tests results 'tpg' folder constains Test Plang Generator
configuration files that can be imported by PTS for tests configuration.
