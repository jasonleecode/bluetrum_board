NimBLE Setup
------------

Most NimBLE initialization is done automatically by
:doc:`sysinit <../../../os/modules/sysinitconfig/sysinitconfig>`. This
section documents the few bits of initialization that an application
must perform manually.

.. toctree::

    ble_lp_clock
    ble_addr
    ble_sync_cb
