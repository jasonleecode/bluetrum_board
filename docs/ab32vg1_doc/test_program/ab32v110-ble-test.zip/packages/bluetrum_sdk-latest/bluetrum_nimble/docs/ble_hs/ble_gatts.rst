NimBLE Host GATT Server Reference
---------------------------------

Introduction
~~~~~~~~~~~~

The Generic Attribute Profile (GATT) manages all activities involving services, characteristics, and descriptors. The
server half of the GATT API handles registration and responding to GATT clients.

API
~~~~~~

.. doxygengroup:: bt_gatt
    :content-only:
    :members:
